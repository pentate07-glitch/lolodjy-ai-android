package ai.lolodjy.pocketoption

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class MainActivity : AppCompatActivity() {

    private lateinit var rootLayout: FrameLayout
    private lateinit var webView: WebView
    private lateinit var lockContainer: LinearLayout
    private lateinit var lockReasonView: TextView
    private lateinit var lockTradesView: TextView
    private lateinit var lockResumeView: TextView
    private lateinit var lockCountdownView: TextView
    private lateinit var prefs: SharedPreferences

    private var cachedBotScript: String? = null
    private val targetUrl = "https://pocketoption.com/fr/cabinet/demo-quick-high-low/"
    private val mainHandler = Handler(Looper.getMainLooper())
    private var tickerRunning = false

    private val PREFS_NAME = "lolodjy_apk_risk_prefs"
    private val KEY_LOCK_UNTIL = "risk_lock_until"
    private val KEY_LOCK_REASON = "risk_lock_reason"
    private val KEY_TRADES_DONE = "risk_trades_done"
    private val KEY_MAX_TRADES = "risk_max_trades"

    inner class LolodjyAndroidBridge {
        @JavascriptInterface
        fun lockAppUntil(untilMsStr: String?, reason: String?, tradesDone: Int, maxTrades: Int) {
            val untilMs = untilMsStr?.toLongOrNull() ?: 0L
            if (untilMs <= System.currentTimeMillis()) return
            prefs.edit()
                .putLong(KEY_LOCK_UNTIL, untilMs)
                .putString(KEY_LOCK_REASON, reason ?: "Vos trades autorisés pour aujourd'hui sont terminés.")
                .putInt(KEY_TRADES_DONE, tradesDone)
                .putInt(KEY_MAX_TRADES, maxTrades)
                .apply()
            mainHandler.post {
                Toast.makeText(
                    this@MainActivity,
                    "⛔ Limite Risk Management atteinte ! Compte & application bloqués.",
                    Toast.LENGTH_LONG
                ).show()
                enforceNativeRiskLock()
            }
        }

        @JavascriptInterface
        fun exitApp() {
            mainHandler.post {
                finishAndRemoveTask()
            }
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun isRiskLocked(): Boolean {
        val until = prefs.getLong(KEY_LOCK_UNTIL, 0L)
        if (until > System.currentTimeMillis()) return true
        if (until > 0L) {
            prefs.edit().remove(KEY_LOCK_UNTIL).remove(KEY_LOCK_REASON).apply()
        }
        return false
    }

    private fun formatRemainingDuration(ms: Long): String {
        val totalSec = kotlin.math.max(0L, (ms + 999L) / 1000L)
        val days = totalSec / 86400L
        val rem = totalSec % 86400L
        val hours = rem / 3600L
        val mins = (rem % 3600L) / 60L
        val secs = rem % 60L
        val hms = String.format(Locale.US, "%02dh %02dm %02ds", hours, mins, secs)
        return if (days > 0) "${days}j $hms" else hms
    }

    private fun formatResumeFrench(ms: Long): String {
        return try {
            val sdf = SimpleDateFormat("EEEE dd/MM/yyyy 'à' HH:mm", Locale.FRENCH)
            sdf.timeZone = TimeZone.getTimeZone("America/Port-au-Prince")
            sdf.format(Date(ms))
        } catch (_: Exception) {
            Date(ms).toString()
        }
    }

    private val lockTickRunnable = object : Runnable {
        override fun run() {
            if (!isRiskLocked()) {
                tickerRunning = false
                restoreTradingView()
                return
            }
            val until = prefs.getLong(KEY_LOCK_UNTIL, 0L)
            lockCountdownView.text = formatRemainingDuration(until - System.currentTimeMillis())
            mainHandler.postDelayed(this, 1000L)
        }
    }

    private fun enforceNativeRiskLock() {
        val until = prefs.getLong(KEY_LOCK_UNTIL, 0L)
        if (until <= System.currentTimeMillis()) {
            restoreTradingView()
            return
        }
        webView.stopLoading()
        webView.loadUrl("about:blank")
        webView.visibility = View.GONE

        lockReasonView.text = prefs.getString(
            KEY_LOCK_REASON,
            "Vos trades autorisés pour aujourd'hui sont terminés."
        )
        val done = prefs.getInt(KEY_TRADES_DONE, 0)
        val max = prefs.getInt(KEY_MAX_TRADES, 1)
        lockTradesView.text = "Trades terminés : $done / $max"
        lockResumeView.text = "Réouverture autorisée : ${formatResumeFrench(until)}"
        lockCountdownView.text = formatRemainingDuration(until - System.currentTimeMillis())

        lockContainer.visibility = View.VISIBLE
        if (!tickerRunning) {
            tickerRunning = true
            mainHandler.postDelayed(lockTickRunnable, 1000L)
        }
    }

    private fun restoreTradingView() {
        lockContainer.visibility = View.GONE
        if (webView.visibility != View.VISIBLE) {
            webView.visibility = View.VISIBLE
            webView.loadUrl(targetUrl)
        }
    }

    private fun buildNativeLockView(): LinearLayout {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#050811"))
            setPadding(dp(20), dp(24), dp(20), dp(24))
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val cardBg = GradientDrawable().apply {
            setColor(Color.parseColor("#0B1120"))
            setStroke(dp(2), Color.parseColor("#EF4444"))
            cornerRadius = dp(18).toFloat()
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = cardBg
            setPadding(dp(20), dp(24), dp(20), dp(24))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val badge = TextView(this).apply {
            text = "⛔"
            textSize = 36f
            gravity = Gravity.CENTER
        }

        val title = TextView(this).apply {
            text = "SITE & APPLICATION BLOQUÉS"
            setTextColor(Color.parseColor("#FCA5A5"))
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(6))
        }

        lockReasonView = TextView(this).apply {
            text = "Vos trades autorisés sont terminés."
            setTextColor(Color.parseColor("#FECACA"))
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(12))
        }

        lockTradesView = TextView(this).apply {
            text = "Trades terminés : 0 / 0"
            setTextColor(Color.parseColor("#E2E8F0"))
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(4))
        }

        lockResumeView = TextView(this).apply {
            text = "Réouverture autorisée : --"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(14))
        }

        val timerBoxBg = GradientDrawable().apply {
            setColor(Color.parseColor("#450A0A"))
            setStroke(dp(1), Color.parseColor("#F87171"))
            cornerRadius = dp(12).toFloat()
        }

        val timerBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = timerBoxBg
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val timerLabel = TextView(this).apply {
            text = "TEMPS RESTANT AVANT RÉOUVERTURE"
            setTextColor(Color.parseColor("#FCA5A5"))
            textSize = 10f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }

        lockCountdownView = TextView(this).apply {
            text = "00h 00m 00s"
            setTextColor(Color.WHITE)
            textSize = 24f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        }

        timerBox.addView(timerLabel)
        timerBox.addView(lockCountdownView)

        val infoText = TextView(this).apply {
            text = "🔒 Protection Capital Stricte : votre compte Pocket Option et cette application restent bloqués jusqu'au jour et à l'heure choisis dans Risk Management."
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(16))
        }

        val exitBtnBg = GradientDrawable().apply {
            setColor(Color.parseColor("#DC2626"))
            cornerRadius = dp(10).toFloat()
        }

        val exitBtn = Button(this).apply {
            text = "🚪 QUITTER L'APPLICATION"
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            background = exitBtnBg
            setPadding(dp(16), dp(12), dp(16), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setOnClickListener {
                finishAndRemoveTask()
            }
        }

        card.addView(badge)
        card.addView(title)
        card.addView(lockReasonView)
        card.addView(lockTradesView)
        card.addView(lockResumeView)
        card.addView(timerBox)
        card.addView(infoText)
        card.addView(exitBtn)
        outer.addView(card)
        return outer
    }

    private fun loadBotScript(): String {
        val existing = cachedBotScript
        if (existing != null) return existing
        val txt = assets.open("lolodjy-bot.js").bufferedReader(Charsets.UTF_8).use { it.readText() }
        cachedBotScript = txt
        return txt
    }

    private fun isPocketOptionHost(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        return url.contains("pocketoption.com") ||
            url.contains("po.trade") ||
            url.contains("pocket-option") ||
            url.contains("pocket24.trade") ||
            url.contains("po2.trade")
    }

    private fun injectBot(view: WebView?) {
        if (view == null || isRiskLocked()) return
        val currentUrl = view.url
        if (!isPocketOptionHost(currentUrl)) return
        val script = loadBotScript()
        view.evaluateJavascript(script, null)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        rootLayout = FrameLayout(this)
        webView = WebView(this)
        lockContainer = buildNativeLockView()

        rootLayout.addView(webView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
        rootLayout.addView(lockContainer)
        setContentView(rootLayout)

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.userAgentString = settings.userAgentString.replace("; wv", "")

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.addJavascriptInterface(LolodjyAndroidBridge(), "LolodjyAndroidBridge")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (isRiskLocked()) {
                    enforceNativeRiskLock()
                    return true
                }
                val u = request?.url?.toString() ?: return false
                if (u.startsWith("https://") || u.startsWith("http://")) {
                    return false
                }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (isRiskLocked() && url != "about:blank") {
                    enforceNativeRiskLock()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (isRiskLocked()) {
                    enforceNativeRiskLock()
                    return
                }
                injectBot(view)
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(view, url, isReload)
                if (isRiskLocked()) {
                    enforceNativeRiskLock()
                    return
                }
                injectBot(view)
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isRiskLocked()) {
                    finishAndRemoveTask()
                    return
                }
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })

        if (isRiskLocked()) {
            enforceNativeRiskLock()
        } else {
            webView.loadUrl(targetUrl)
        }
    }

    override fun onResume() {
        super.onResume()
        if (isRiskLocked()) {
            enforceNativeRiskLock()
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(lockTickRunnable)
        super.onDestroy()
    }
}
