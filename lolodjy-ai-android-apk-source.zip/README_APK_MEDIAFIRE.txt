===================================================================
LOLODJY AI v14.5.0 - PROJET APK ANDROID CONNECTÉ À POCKETOPTION.COM
===================================================================

Ce dossier contient le code source complet d'une application Android
WebView Kotlin prête à compiler qui ouvre directement :
  https://pocketoption.com/fr/cabinet/demo-quick-high-low/
et injecte automatiquement le bot LOLODJY AI v14.5.0 complet
(app/src/main/assets/lolodjy-bot.js) avec :
- Espace 🎯 Trade Seul
- Espace 📊 50 IA & 6 Scanners + Détection Auto WIN / LOSS + Martingale
- Espace 🛡️ Risk Mgmt (Blocage TOTAL du site, du compte et rejet natif APK jusqu'au jour/heure choisis)
- Espace 👑 OWNER Cloud & Firebase Auth/Firestore

ÉTAPES POUR GÉNÉRER VOTRE FICHIER .APK ET L'ENVOYER SUR MEDIAFIRE :
1. Décompressez lolodjy-ai-android-apk-source.zip sur votre PC/Mac.
2. Ouvrez le dossier dans Android Studio (ou utilisez .github/workflows/build-apk.yml sur GitHub).
3. Laissez Gradle synchroniser les dépendances.
4. Dans le menu : Build -> Build Bundle(s) / APK(s) -> Build APK(s)
   (ou Build -> Generate Signed Bundle / APK pour une version signée).
5. Récupérez le fichier APK généré dans :
   app/build/outputs/apk/debug/app-debug.apk (ou release/app-release.apk).
6. Connectez-vous à votre compte sur https://www.mediafire.com et téléversez
   ce fichier .apk pour obtenir votre lien MediaFire.
7. Collez ce lien MediaFire dans votre portail (onglet "📲 Site APK MediaFire") :
   votre propre site de distribution APK (?site=apk) est prêt à partager !

ALTERNATIVE IMMÉDIATE SUR ANDROID (SANS COMPILER D'APK) :
- Installez Firefox Android, Kiwi Browser ou Yandex Browser sur votre téléphone,
  chargez "lolodjy-ai-v14.5.0.zip", et ouvrez https://pocketoption.com.
